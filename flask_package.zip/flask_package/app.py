from pathlib import Path
from uuid import uuid4
from flask import Flask,render_template,request
from werkzeug.utils import secure_filename
from inference import predict_damage
BASE=Path(__file__).resolve().parent; UPLOAD=BASE/'static'/'uploads'; UPLOAD.mkdir(parents=True,exist_ok=True)
app=Flask(__name__); app.config['MAX_CONTENT_LENGTH']=16*1024*1024
ALLOWED={'png','jpg','jpeg'}
def ok(name): return '.' in name and name.rsplit('.',1)[1].lower() in ALLOWED
@app.route('/',methods=['GET','POST'])
def index():
    result=error=pre_url=post_url=None
    if request.method=='POST':
        pre=request.files.get('pre_image'); post=request.files.get('post_image')
        if not pre or not post: error='Upload both images.'
        elif not ok(pre.filename) or not ok(post.filename): error='Use PNG, JPG or JPEG.'
        else:
            token=uuid4().hex; pn=f'{token}_pre_{secure_filename(pre.filename)}'; qn=f'{token}_post_{secure_filename(post.filename)}'; pp=UPLOAD/pn; qp=UPLOAD/qn; pre.save(pp); post.save(qp); result=predict_damage(pp,qp); pre_url=f'/static/uploads/{pn}'; post_url=f'/static/uploads/{qn}'
    return render_template('index.html',result=result,error=error,pre_url=pre_url,post_url=post_url)
if __name__=='__main__': app.run(debug=True)
