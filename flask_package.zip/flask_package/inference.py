from pathlib import Path
import json, numpy as np, torch
from PIL import Image
BASE=Path(__file__).resolve().parent
CONFIG=json.loads((BASE/'model_config.json').read_text())
CLASSES=CONFIG['class_names']; SIZE=int(CONFIG['input_size']); MEAN=np.array(CONFIG['imagenet_mean'],dtype=np.float32); STD=np.array(CONFIG['imagenet_std'],dtype=np.float32)
DEVICE=torch.device('cuda' if torch.cuda.is_available() else 'cpu')
MODEL=torch.jit.load(str(BASE/'best_damage_model_scripted.pt'),map_location=DEVICE).eval()
def prep(path):
    a=np.asarray(Image.open(path).convert('RGB').resize((SIZE,SIZE)),dtype=np.float32)/255.; a=(a-MEAN)/STD
    return torch.from_numpy(a.transpose(2,0,1)).float().unsqueeze(0).to(DEVICE)
@torch.no_grad()
def predict_damage(pre_path,post_path):
    p=torch.softmax(MODEL(prep(pre_path),prep(post_path)),1)[0].cpu().numpy(); i=int(p.argmax())
    return {'predicted_class':CLASSES[i],'confidence':float(p[i]),'probabilities':{c:float(p[j]) for j,c in enumerate(CLASSES)}}
